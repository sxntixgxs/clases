#ejercicio 1
#hacer un programa en Python que genere el siguiente numero de la secuencia: 
# 1,1,2,-1,1,-2,?
#1 + 1 = 2
#1 + - 2 = 1
# 2 + -1 = 1
# -1 - 1 = -2
# 1 + -2 = -1 ESTE ES el que sigue

n1=1
n2=1
sig=-1
for i in range(5):
    s = n1+(sig**i)*n2
    n1= n2
    n2=s
    print(s,end=", ")
"""hacerle la prueba de escritorio en la casa y mirar q de lo mismo
cuando tenga un problema donde el signo cambie + - se pone una variable sig=-+1
y dentro de la operacion es sig**i para que se vaya intercambiando
debido a que es se esta elevando a un par y luego a un impar durante lo que dure
el ciclo"""
