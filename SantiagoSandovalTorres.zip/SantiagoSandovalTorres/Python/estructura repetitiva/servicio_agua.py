n=int(input("\nIngrese el numero de usuarios: "))
for i in range(n):
    print(f"Datos del usuario #{i}")
    codigo=input("Codigo: ")
    nombre=input("Nombre: ")
    estado=input("Vigente(v) o Suspendido(s): ")
    estrato=int(input("Estrato :"))
    consumo=float(input("Consumo: "))
    if estado=="v" or estado=="V":
        if estrato==1:
            tBasica=10_000
        elif estrato==2:
            tBasica=20_000
        elif estrato==3:
            tBasica=30_000
        elif estrato==4:
            tBasica=45_000
        elif estrato==5:
            tBasica=60_000
        else:
            tBasica=70_000
        vConsumo=(consumo*200)
        pr=vConsumo+tBasica
        barras="="*15
        print(f"\n{barras}\n{nombre}\n${tBasica:,}\n${vConsumo:,}\n${pr:,}\n{barras}")
    else: print(f"\n{nombre}\nUsuario SUSPENDIDO")

