#calcular el factorial de un numero
# 5! = 5*4*3*2*1

num=int(input("Ingrese el numero: "))
fact=1
for i in range(1,num+1):
    fact*=i
print(f"El factorial de {num} es {fact:,}")    
