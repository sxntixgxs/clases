#ciclo for
#for i in range(10):
#    print(i) #i va a tomar los valores que genera range
            #range 10 va a repetir el ciclo 10 veces, desde 0 a 9
            #cada repeticion se guara en i
            #por defecto cada vez q imprime un valor de i cambia de linea
            #si quiero que el final no sea un cambio de linea sino una "," por ejemplo
            #la forma de hacerlo es print(i,end=", ")

#for i in range(10):
#    print(i, end=", ")

# si quiero imprimir
# ******
# *    *
# *    *
# *    *
# ******
# para sacar numeral ctrl k ctrl c
# for i in range(6):
#     print("*",end="")
# print("") #primera fila y cambio de linea con este print
# for i in range(2):
#     print("*    *")#filas del medio; al no ponerle end termina el patron y cambia de linea
# for i in range(6):
#     print("*",end="")#ultima fila

# *
# ***
# ****
# *****
lineas=int(input("ingrese el numero de lineas"))
for i in range(lineas):
    print("*"*(i+1))#i+1 porque arranca desde 0 entonces al multiplicar * i =0 esa linea no se va a ver
    
