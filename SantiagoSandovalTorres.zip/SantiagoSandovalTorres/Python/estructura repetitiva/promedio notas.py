#capturar las notas de un curso y calcular el promedio deestas  ; 
#imprimir resultado promedio

cant = int(input("Ingrese la cantidad de notas: "))
sumaNota=0
for i in range(1,cant+1): #para q arranque en uno y no arranque en 0 al mostrarlo, solo seria por vista
    nota=float(input(f"Ingrese la nota #{i} "))
    sumaNota+=nota
prom=sumaNota/cant    
print(f"El promedio de notas es: {prom:.1f}")



