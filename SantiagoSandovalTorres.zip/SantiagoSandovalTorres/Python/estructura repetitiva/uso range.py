#FUNCION range([ini], fin, [incr]) lo que esta en [] es opcional, sin nada es obligatorio, es decir, el fin es obligatorio

print(list(range(5))) #-> 0, 1, 2, 3, 4
print(list(range(19)))#0, ...,18 EL FIN NO SE INCLUYE

print(list(range(2,10)))#2, ..., 9
print(list(range(15,-3)))#[] como el incremento por defecto es de uno en uno positivo, no hay forma de llegar

print(list(range(2,10,3)))#2,5,8
print(list(range(15,-3,-1)))#15, ..., -2

print(list(range(1,5,3)))#1,4