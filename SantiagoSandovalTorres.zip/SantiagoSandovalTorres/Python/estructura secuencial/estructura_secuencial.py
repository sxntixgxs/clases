#punto 1:
def punto1()->None:
    dato="*"
    print(dato+"\n"+dato*2+"\n"+dato*3+"\n"+dato*4+"\n"+dato*5)
    return
punto1()
#punto 2:
def punto2()->None:
    print("\nPUNTO 2")
    print("*"*9+"\n*\t*\n*\t*\n*\t*\n"+"*"*9)
    return
punto2()
#punto 3
def punto3()->None:
    pr=""
    horas=int(input("Ingrese la cantidad de horas trabajadas: "))
    bruto=horas*20000
    dscunit=(bruto*(4/100))
    neto=bruto-(dscunit*2)
    prbruto="${:,}".format(bruto)
    prdsc="${:,}".format(dscunit)
    prneto="${:,}".format(neto)
    pr="El sueldo bruto es: "+prbruto+"\nDESCUENTO EPS: "+prdsc+"\nDESCUENTO PENSION: "+prdsc+"\nSUELDO FINAL: "+prneto
    print(pr)
    return 
punto3()
#punto 4
def punto4()->None:
    s=int(input("Ingrese los segundos: "))
    h=s//(60*60)
    min=(s%(60*60))//60
    sf=s%60
    print(str(h)+" horas\n"+str(min)+" minutos\n"+str(sf)+" segundos.")
    return
punto4()

def punto5()->None:
    nota=float(input("Ingrese la nota: "))
    curva=(nota*0.8)+1
    print("La curva de 8 de la nueva nota es: {:.2f}".format(curva))
    return
punto5()
