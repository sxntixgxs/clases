#ejemplos de formatear la salida
#con format
sueldo=5600000
print("Sueldo: ${:,}".format(sueldo))#el : es como el formato q se llena {:} al lado de los : van
#los caracteres que separan, ya vienen determinados, es una lista ?????
#en este caso, la ',' separa cada 3 
#abajo por ejemplo ponemos la coma .3f con esto separamos cada 3 exactamente igual peeero solo quie
#ro mantener 3 decimales no màs
#BUSCAR Y LEER DOCUMENTACION DE FORMAT; LA OFICIAL DE PYTHON.
interes=2568.568954112568
print("valor interes: ${:,.3f}".format(interes))


#f-string
print(f"Sueldo: ${sueldo:,}")#mismas reglas q format; la variable va por dentro de los {}
#inicia con f.
#esta forma es como la màs reciente; ultimas versiones
print(f"valor interes: ${interes:,.3f}")