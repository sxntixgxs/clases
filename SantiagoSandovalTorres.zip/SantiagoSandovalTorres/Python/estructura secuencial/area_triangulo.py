"""Calcular el area de un triangulo"""
base=float(input("Ingrese la base del triangulo: "))
altura=float(input("Ingrese la altura del triangulo: "))
print("El area del triangulo es: ",(base*altura)/2)