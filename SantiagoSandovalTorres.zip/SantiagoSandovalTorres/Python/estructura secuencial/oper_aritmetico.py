num1=5
num2=2
print("suma",num1+num2)
print("resta",num1-num2)
print("multiply",num1*num2)
print("division",num1/num2)
print("division int",num1//num2)
print("modulo",num1%num2)
print("potencia",num1**num2)
print("ex",5%13)
