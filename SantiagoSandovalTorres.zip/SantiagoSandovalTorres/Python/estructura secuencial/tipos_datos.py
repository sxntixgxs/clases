import math as m
edad=25
print("edad:",type(edad))
edad="sapo"
print("str:",type(edad))
edad=m.pi
print("float:",type(edad))
single=False
print("soltero:",type(single))