def punto4()->None:
    s=int(input("Ingrese los segundos: "))
    h=s//(60*60)
    min=(s%(60*60))//60
    sf=s%60
    print(str(h)+" horas\n"+str(min)+" minutos\n"+str(sf)+" segundos.")
    return
punto4()