#mayor a menor
a=int(input("Ingrese un numero entero "))
b=int(input("Ingrese un numero entero "))
c=int(input("Ingrese un numero entero "))
if a>=b and a>=c:
    primero=a
    if b>=c:
        segundo=b
        tercero=c
    else: 
        segundo=c
        tercero=b
elif b>=a and b>=c:
    primero=b
    if a>=c:
        segundo=a
        tercero=c
    else:
        segundo=c
        tercero=a
else: 
    primero=c
    if a>=b:
        segundo=a
        tercero=b
    else: 
        segundo=b
        tercero=a
print(str(primero)+", "+str(segundo)+", "+str(tercero))
    