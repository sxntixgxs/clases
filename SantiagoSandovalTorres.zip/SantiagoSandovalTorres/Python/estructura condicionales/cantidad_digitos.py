#ex contar cantidad de digitos con if
import math as m
n=int(input("Ingrese el numero: "))
if n<0:
    n*=-1 # n =     -1 * n
cantDig=m.floor(m.log10(n))+1 #floor redondea a la parte inferior ej: m.floor(3.9) = 3
print(cantDig)
    