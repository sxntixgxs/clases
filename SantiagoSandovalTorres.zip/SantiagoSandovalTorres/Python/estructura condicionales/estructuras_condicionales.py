#punto 1
def punto1()->None:
    distancia=float(input("Ingrese la distancia del recorrido en km: "))
    dias=int(input("Ingrese los dias de estancia: "))
    pr=distancia*0.63
    if distancia>800 and dias>7:
        prD=round(pr-(pr*(30/100)),2)
        print("El precio con 30% de descuento es: ${:,}".format(prD))
    else: print("El precio por el recorrido es: ${:,}".format(round(pr,2)))

    return
punto1()
#punto 2
def punto2()->None:
    año=int(input("Ingrese el año: "))
    op=año%4
    pr="no es biciesto"

    if op==0:
        if año//100>0 and año//400>0:
            pr="es biciesto"
            print(pr)
    else: print(pr)
    return 
punto2()
#punto 3
def punto3()->None:
    weight=float(input("Enter weight in pounds: "))
    height=float(input("Enter height in inches: "))
    hMeters=height*0.0254
    wKilos=weight*0.45359237
    bmi=wKilos/(hMeters**2)
    pr=""
    if bmi<18.5:
        pr="Underweight"
    elif 18.5<=bmi<=24.9:
        pr="Normal"
    elif 25<=bmi<=29.9:
        pr="Overweight"
    else: pr="Obese"
    print("The bmi is: {:.2f}".format(bmi),"\n",pr)
    return
punto3()
#punto4
def punto4()->None:
    today=int(input("Enter today's day: "))
    ftre=int(input("Enter the numbers of days elapsed since today: "))
    dayF=today+ftre
    dayPr=""
    if dayF>6:
        dayL=dayF%7
    else: dayL=dayF
    if dayL==0:
        dayPr="Sunday"
    elif dayL==1:
        dayPr="Monday"
    elif dayL==2:
        dayPr="Tuesday"
    elif dayL==3:
        dayPr="Wendsday"
    elif dayL==4:
        dayPr="Thursday"
    elif dayL==5:
        dayPr="Friday"
    elif dayL==6:
        dayPr="Saturday"
    else: dayPr="Error; restart the program."
    print(dayPr)
    return
punto4()
#punto 5
def punto5()->None:
    number=int(input("Enter the number: "))
    divi=number%10
    count=1
    if divi!=number:
        count+=1
        diviCent=number%(10**count)
        print(count)
        if diviCent!=number:
            count+=1
            diviMil=number%(10**count)
            print(count)
    else: print(count)     
    return
punto5()
def punto5()->None:
    number=int(input("Enter the number: "))
    divi=number%(10**15)
    count=1
    if   
    return
punto5()
