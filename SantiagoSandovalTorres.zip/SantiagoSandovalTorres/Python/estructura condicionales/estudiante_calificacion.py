def prueba()->None:
    estudiante=str(input("ingrese el nombre del estudiante "))
    nota=float(input("Ingrese la nota "))
    prNota=""
    if 0<=nota<=59:
        prNota="D"
    elif 60<=nota<=79:
        prNota="C"
    elif 80<=nota<=89:
        prNota="B"
    elif nota>=90:
        prNota="A"
    else: 
        prNota=""
        print("Error, nota invalida. Reinicie el programa")
    print("El estudiante "+estudiante+" saco "+prNota)
    return
prueba()