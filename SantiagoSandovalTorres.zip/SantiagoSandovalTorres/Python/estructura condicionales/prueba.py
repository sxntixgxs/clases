def punto4()->None:
    today=int(input("Enter today's day: "))
    ftre=int(input("Enter the numbers of days elapsed since today: "))
    dayF=today+ftre
    dayPr=""
    if dayF>6:
        dayL=dayF%7
    else: dayL=dayF
    if dayL==0:
        dayPr="Sunday"
    elif dayL==1:
        dayPr="Monday"
    elif dayL==2:
        dayPr="Tuesday"
    elif dayL==3:
        dayPr="Wendsday"
    elif dayL==4:
        dayPr="Thursday"
    elif dayL==5:
        dayPr="Friday"
    elif dayL==6:
        dayPr="Saturday"
    else: dayPr="Error; restart the program."
    print(dayPr)
    return
punto4()