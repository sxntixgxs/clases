#condicional simple
sueldo =1_100_000 #la maquina igual lo entiende como int
sueldoMin=1_160_000

if sueldo<=sueldoMin:
    auxTrans=140_000
else: auxTrans= 0
print(f"Auxilio de Transporte ${auxTrans:,}")
